
# Aula sobre Prototipação de Telas

## Introdução à Prototipação de Telas

### O que é Prototipação de Telas?
Prototipação de telas é o processo de criar modelos iniciais de interfaces de usuário para aplicativos e websites.

### Importância da Prototipação
- **Teste de Usabilidade:** Permite testar a usabilidade antes de codificar.
- **Comunicação de Ideias:** Facilita a comunicação entre equipes.
- **Economia de Tempo e Recursos:** Identifica problemas de design cedo.

## Ferramentas de Prototipação
- Adobe XD
- Sketch
- Figma
- InVision

## Processo de Prototipação
1. **Definição de Requisitos**
2. **Esboços Iniciais**
3. **Design de Alta Fidelidade**
4. **Teste com Usuários**
5. **Iteração**

## Exemplos de Protótipos

### Exemplo 1: Protótipo de Baixa Fidelidade
Esboço simples à mão de um aplicativo móvel.

![Protótipo de Baixa Fidelidade](Hand-drawn_sketch_of_a_mobile_app_prototype_showin.png)

### Exemplo 2: Protótipo de Média Fidelidade
Design digital mais refinado no computador.

![Protótipo de Média Fidelidade](Digital_design_of_a_medium-fidelity_prototype_for_.png)

### Exemplo 3: Protótipo de Alta Fidelidade
Design completo com cores, imagens e interatividade.

![Protótipo de Alta Fidelidade](High-fidelity_prototype_design_for_a_mobile_app_in.png)
